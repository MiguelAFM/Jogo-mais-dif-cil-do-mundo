var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["996ca2d4-72a8-4050-a1ed-9616f71ba40e","97a66067-d002-475a-a741-01a47c70e6de","afcf10a0-258b-4df8-8fe3-c729cc141c1e","8acb0947-a14d-4ce5-8ac7-8c611a33a14a","abe8010a-2186-4640-9a95-6e529d1b2639","4cc7a791-0e91-4c2d-aca7-fb71c2bc3bbf","2edbc231-1e70-4aed-b7fa-1d7dda015bdf","7776fbc5-c13b-4872-9780-58fd7052542d","9e4438c0-02cb-4812-bf9d-8501848078bd","8ed8394b-1a08-4446-9729-83a33ed00393"],"propsByKey":{"996ca2d4-72a8-4050-a1ed-9616f71ba40e":{"name":"rpgcharacter_10_1","sourceUrl":"assets/api/v1/animation-library/gamelab/yeYHxzJDSVARt9bjkAajoPd5ik3WxGo1/category_fantasy/rpgcharacter_10.png","frameSize":{"x":264,"y":243},"frameCount":1,"looping":true,"frameDelay":2,"version":"yeYHxzJDSVARt9bjkAajoPd5ik3WxGo1","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":243},"rootRelativePath":"assets/api/v1/animation-library/gamelab/yeYHxzJDSVARt9bjkAajoPd5ik3WxGo1/category_fantasy/rpgcharacter_10.png"},"97a66067-d002-475a-a741-01a47c70e6de":{"name":"rpgcharacter_07_1","sourceUrl":"assets/api/v1/animation-library/gamelab/nuGcPmuvycktJ3yt6exTfjxaGLoA1pc_/category_fantasy/rpgcharacter_07.png","frameSize":{"x":282,"y":209},"frameCount":1,"looping":true,"frameDelay":2,"version":"nuGcPmuvycktJ3yt6exTfjxaGLoA1pc_","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":282,"y":209},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nuGcPmuvycktJ3yt6exTfjxaGLoA1pc_/category_fantasy/rpgcharacter_07.png"},"afcf10a0-258b-4df8-8fe3-c729cc141c1e":{"name":"rpgcharacter_06_1","sourceUrl":"assets/api/v1/animation-library/gamelab/_YiuzeciqQNeKYmJiXDkwIdSsA6FT9FE/category_fantasy/rpgcharacter_06.png","frameSize":{"x":206,"y":237},"frameCount":1,"looping":true,"frameDelay":2,"version":"_YiuzeciqQNeKYmJiXDkwIdSsA6FT9FE","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":206,"y":237},"rootRelativePath":"assets/api/v1/animation-library/gamelab/_YiuzeciqQNeKYmJiXDkwIdSsA6FT9FE/category_fantasy/rpgcharacter_06.png"},"8acb0947-a14d-4ce5-8ac7-8c611a33a14a":{"name":"rpgcharacter_04_1","sourceUrl":"assets/api/v1/animation-library/gamelab/zrh9fKR_85SGEPTiZYS44Q0Hv.r7yAzL/category_fantasy/rpgcharacter_04.png","frameSize":{"x":338,"y":243},"frameCount":1,"looping":true,"frameDelay":2,"version":"zrh9fKR_85SGEPTiZYS44Q0Hv.r7yAzL","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":338,"y":243},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zrh9fKR_85SGEPTiZYS44Q0Hv.r7yAzL/category_fantasy/rpgcharacter_04.png"},"abe8010a-2186-4640-9a95-6e529d1b2639":{"name":"rpgcharacter_05_1","sourceUrl":"assets/api/v1/animation-library/gamelab/NVWLyQ7eFA78l2aOE1XO4ZMdIKEXp338/category_fantasy/rpgcharacter_05.png","frameSize":{"x":214,"y":209},"frameCount":1,"looping":true,"frameDelay":2,"version":"NVWLyQ7eFA78l2aOE1XO4ZMdIKEXp338","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":214,"y":209},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NVWLyQ7eFA78l2aOE1XO4ZMdIKEXp338/category_fantasy/rpgcharacter_05.png"},"4cc7a791-0e91-4c2d-aca7-fb71c2bc3bbf":{"name":"farm_land_1","sourceUrl":"assets/api/v1/animation-library/gamelab/B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx/category_backgrounds/farm_land.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/B7nUqE7MHvtM.bH.nFWaMiZcfScwjIfx/category_backgrounds/farm_land.png"},"2edbc231-1e70-4aed-b7fa-1d7dda015bdf":{"name":"dingo_1","sourceUrl":"assets/api/v1/animation-library/gamelab/xISWm91StiQQ4m_8EgGr4O4cUpTGfOBM/category_animals/dingo.png","frameSize":{"x":306,"y":397},"frameCount":1,"looping":true,"frameDelay":2,"version":"xISWm91StiQQ4m_8EgGr4O4cUpTGfOBM","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":306,"y":397},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xISWm91StiQQ4m_8EgGr4O4cUpTGfOBM/category_animals/dingo.png"},"7776fbc5-c13b-4872-9780-58fd7052542d":{"name":"fox_1","sourceUrl":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png","frameSize":{"x":394,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png"},"9e4438c0-02cb-4812-bf9d-8501848078bd":{"name":"lynx_1","sourceUrl":"assets/api/v1/animation-library/gamelab/LDBImZgauirtUC6VmxoruWx5J.5PjbyH/category_animals/lynx.png","frameSize":{"x":396,"y":397},"frameCount":1,"looping":true,"frameDelay":2,"version":"LDBImZgauirtUC6VmxoruWx5J.5PjbyH","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":397},"rootRelativePath":"assets/api/v1/animation-library/gamelab/LDBImZgauirtUC6VmxoruWx5J.5PjbyH/category_animals/lynx.png"},"8ed8394b-1a08-4446-9729-83a33ed00393":{"name":"cuteanimals_bunny_1","sourceUrl":"assets/api/v1/animation-library/gamelab/BaBhTMgCAJP8j1hdaqVVhT6JJs4Wmmva/category_animals/cuteanimals_bunny.png","frameSize":{"x":344,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"BaBhTMgCAJP8j1hdaqVVhT6JJs4Wmmva","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":344,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/BaBhTMgCAJP8j1hdaqVVhT6JJs4Wmmva/category_animals/cuteanimals_bunny.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var start = createSprite(10, 200, 100, 150);
start.shapeColor = "lightblue";
var finish = createSprite(390, 200, 100, 150);
finish.shapeColor = "yellow";
var topwall = createSprite(200, 275, 400, 5);
var bottomwall = createSprite(200, 125, 400, 5);
var player = createSprite(10, 200, 20, 20);
player.setAnimation("rpgcharacter_10_1");
player.scale = 0.1;
var enemy1 = createSprite(100, 260, 20, 20);
enemy1.velocityY = 5;
enemy1.setAnimation("rpgcharacter_07_1");
enemy1.scale = 0.15;
var enemy2 = createSprite(170, 130, 20, 20);
enemy2.velocityY = 5;
enemy2.setAnimation("rpgcharacter_06_1");
enemy2.scale = 0.15;
var enemy3 = createSprite(230, 260, 20, 20);
enemy3.velocityY = 5;
enemy3.setAnimation("rpgcharacter_04_1");
enemy3.scale = 0.15;
var enemy4 = createSprite(300, 130, 20, 20);
enemy4.velocityY = 5;
enemy4.setAnimation("rpgcharacter_05_1");
enemy4.scale = 0.15;
var fox = createSprite(200, 370);
fox.setAnimation("fox_1");
fox.scale = 0.1;
var dog = createSprite(100, 370);
dog.setAnimation("dingo_1");
dog.scale = 0.1;
var lynx = createSprite(300, 370);
lynx.setAnimation("lynx_1");
lynx.scale = 0.1;
var bunny = createSprite(375, 200);
bunny.setAnimation("cuteanimals_bunny_1");
bunny.scale = 0.1;
var score = 0;
function draw() {
  background("green");
  drawSprites();
  textSize(20);
  text("Falhas: " + score, 0, 15);
  createEdgeSprites();
  player.bounceOff(edges);
  enemy1.bounceOff(edges);
  enemy2.bounceOff(edges);
  enemy3.bounceOff(edges);
  enemy4.bounceOff(edges);
  player.bounceOff(topwall);
  player.bounceOff(bottomwall);
  enemy1.bounceOff(topwall);
  enemy1.bounceOff(bottomwall);
  enemy2.bounceOff(topwall);
  enemy2.bounceOff(bottomwall);
  enemy3.bounceOff(topwall);
  enemy3.bounceOff(bottomwall);
  enemy4.bounceOff(topwall);
  enemy4.bounceOff(bottomwall);
  if (keyDown("up")) {
    player.y = player.y - 3;
  }
  if (keyDown("down")) {
    player.y = player.y + 3;
  }
  if (keyDown("left")) {
    player.x = player.x - 3;
  }
  if (keyDown("right")) {
    player.x = player.x + 3;
  }
  if (player.isTouching(enemy1)) {
    player.x = 10;
    player.y = 200;
    score = score + 1;
    playSound("assets/category_app/app_interface_button_4.mp3");
  }
  if (player.isTouching(enemy2)) {
    player.x = 10;
    player.y = 200;
    score = score + 1;
    playSound("assets/category_app/app_interface_button_4.mp3");
  }
  if (player.isTouching(enemy3)) {
    player.x = 10;
    player.y = 200;
    score = score + 1;
    playSound("assets/category_app/app_interface_button_4.mp3");
  }
  if (player.isTouching(enemy4)) {
    player.x = 10;
    player.y = 200;
    score = score + 1;
    playSound("assets/category_app/app_interface_button_4.mp3");
  }
  if (player.isTouching(finish)) {
    textSize(20);
    text("Você ganhou", 200, 200);
    player.x = 350;
    player.y = 200;
    playSound("assets/category_achievements/lighthearted_bonus_objective_3.mp3");
    stopSound("assets/category_achievements/lighthearted_bonus_objective_3.mp3");
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
